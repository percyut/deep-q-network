from sklearn import metrics
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import learning_curve
from sklearn.model_selection import ShuffleSplit
from sklearn.cross_validation import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import confusion_matrix, roc_curve,auc
from sklearn import svm
from sklearn.metrics import accuracy_score
import itertools
from mpl_toolkits.mplot3d import Axes3D

#plot learning curve might cause some error on normal IDE, however, all codes can run perfectly on Jupyter Notebook

df = pd.read_csv("https://archive.ics.uci.edu/ml/machine-learning-databases/housing/housing.data", header = None)#read csv file

foo = lambda x: pd.Series([i for i in reversed(x.split())])#for some reason, there is only one colulmn in the csv file,so have to split them
rev = df[0].apply(foo)
rev.columns = ["MEDV","LSTAT","B","PTRATIO","TAX","RAD","DIS","AGE","RM","NOX","CHAS","INDUS","ZN","CRIM"]#rename each column
rev=pd.DataFrame(rev,dtype=np.float)#reset dataframe to be float
X=rev.iloc[:,1:]
y=rev["MEDV"]
sum=0
#caculate mean of y
for i in y:
    sum=sum+float(i)
meanval=sum/len(y.tolist())
print(meanval)
#replace each data in value with new data
y[y>=meanval]=1
y[y!=1]=0

#split data to training set and test set
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)
#Standardlize data
sc = StandardScaler()
sc.fit(X_train)
countcheap=0
countexpen=0
for i in y:
    if i==1:
        countexpen=countexpen+1
    elif i==0:
        countcheap=countcheap+1

print("Cheap:",countcheap)
print("Expensive",countexpen)
print(X.info)
print(rev.info)

X_train_std = sc.transform(X_train)
X_test_std = sc.transform(X_test)

#draw a 3d graph of column["RM"] and column["CRIM"]
ax = plt.subplot(projection='3d')
ax.scatter(X_train["RM"], X_train["CRIM"], y_train, c='r')

ax.set_zlabel('Z')
ax.set_ylabel('Y')
ax.set_xlabel('X')

plt.draw()
plt.pause(10)
plt.savefig('3D.jpg')
plt.close()

#training data with LinearSVC model
svmp=svm.LinearSVC()
svmp.fit(X_train_std,y_train)
y_pred=svmp.predict(X_test_std)#get predict value

#training data with LogisticRegression
classifier = LogisticRegression()
classifier.fit(X_train_std,y_train)
y_pred_logistic=classifier.predict(X_test_std)

y_scoret=classifier.fit(X_train_std,y_train).decision_function(X_test)#get scores of test set
y_score = svmp.fit(X_train, y_train).decision_function(X_test)

print('Misclassified samples: %d' % (y_test != y_pred).sum())#caculate accuracy and misclassified samples
print('Accuracy: %.2f' % accuracy_score(y_test, y_pred))

#plot learning curve
#estimator is the classifier that used in training,
#ylim is the range,here set the range [0,1.01]
#cv is cross validation. Although at the begining we used train_test_split,but for some reason willn occur some error, so here we use another function called"Shufflesplit"
def plot_learning_curve(estimator, title, X, y, ylim=None, cv=None,n_jobs=None, train_sizes=np.linspace(.1, 1.0, 5)):
    plt.figure()
    plt.title(title)
    if ylim is not None:
        plt.ylim(*ylim)
    plt.xlabel("Training examples")
    plt.ylabel("Score")
    train_sizes, train_scores, test_scores = learning_curve(estimator, X, y, cv=cv, n_jobs=n_jobs, train_sizes=train_sizes)
    #plot the point on the curve
    train_score_mean = np.mean(train_scores, axis=1)
    train_score_std = np.std(train_scores, axis=1)
    test_score_mean = np.mean(test_scores, axis=1)
    test_score_std = np.std(test_scores, axis=1)
    plt.grid()

    plt.fill_between(train_sizes, train_score_mean - train_score_std,train_score_mean + train_score_std, alpha=0.1,color="r")
    plt.fill_between(train_sizes, test_score_mean - test_score_std,test_score_mean + test_score_std, alpha=0.1, color="g")
    plt.plot(train_sizes, train_score_mean, 'o-', color="r",label="Training score")
    plt.plot(train_sizes, test_score_mean, 'o-', color="g",label="test score")

    plt.legend(loc="best")
    return plt

#plot_learning_curve(svmp, "Learning curves for SVM", X_train_std,y_train, (0.0, 1.01),ShuffleSplit(n_splits=10, test_size=0.2, random_state=0), n_jobs=4)
#plt.show()

#plot roc curve of
fpr, tpr,_=roc_curve(y_test,y_score,drop_intermediate=False)
fpt, tpt,_=roc_curve(y_test,y_scoret,drop_intermediate=False)
plt.figure()
roc_auc = auc(fpr, tpr)  #caculate auc
roc_auct=auc(fpt,tpt)

plt.figure()
lw = 2
plt.figure(figsize=(10, 10))
plt.plot(fpr, tpr, color='darkorange',lw=lw, label='ROC curve (area = %0.2f)' % roc_auc)
plt.plot(fpt, tpt, color="r",lw=lw, label="ROC curve(logistic)(area=%0.2f)" %roc_auct)
plt.plot([0, 1], [0, 1], color='navy', lw=lw, linestyle='--')
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.05])
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('Receiver operating characteristic example')
plt.legend(loc="lower right")

plt.show()

#plot the confusion matrix based on the confusion matrix that was caculated in other steps
class_names=["cheap","expensive"]
#
def plot_confusion_matrix(cm, classes,normalize=False,title='Confusion matrix',cmap=plt.cm.Blues):

    if normalize:
        cm = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
        print("Normalized confusion matrix")
    else:
        print('Confusion matrix, without normalization')

    print(cm)

    plt.imshow(cm, interpolation='nearest', cmap=cmap)
    plt.title(title)
    plt.colorbar()
    tick_marks = np.arange(len(classes))
    plt.xticks(tick_marks, classes, rotation=45)
    plt.yticks(tick_marks, classes)

    fmt = '.2f' if normalize else 'd'
    thresh = cm.max() / 2.
    for i, j in itertools.product(range(cm.shape[0]), range(cm.shape[1])):
        plt.text(j, i, format(cm[i, j], fmt),horizontalalignment="center",color="white" if cm[i, j] > thresh else "black")

    plt.ylabel('True label')
    plt.xlabel('Predicted label')
    plt.tight_layout()


# Compute confusion matrix
cnf_matrix = confusion_matrix(y_test, y_pred)
np.set_printoptions(precision=2)

plt.figure()
plot_confusion_matrix(cnf_matrix, classes=class_names, normalize=True,title='Normalized confusion matrix')

plt.show()


