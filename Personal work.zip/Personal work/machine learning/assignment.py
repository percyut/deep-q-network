from sklearn.linear_model import LinearRegression
from sklearn import metrics
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.model_selection import learning_curve
from sklearn.cross_validation import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.cross_validation import ShuffleSplit

#plot learning curve might cause some error on normal IDE, however, all codes can run perfectly on Jupyter Notebook
#%matplotlib inline

#read csv file
df = pd.read_csv("https://archive.ics.uci.edu/ml/machine-learning-databases/housing/housing.data", header = None)

#the same data preprocess steps as assignmnetpart2.py
foo = lambda x: pd.Series([i for i in reversed(x.split())])
rev = df[0].apply(foo)
rev.columns = ["MEDV","LSTAT","B","PTRATIO","TAX","RAD","DIS","AGE","RM","NOX","CHAS","INDUS","ZN","CRIM"]
rev=pd.DataFrame(rev,dtype=np.float)
t=rev.iloc[:,1:]
t=t[t["RM"]>=6]
rev=rev[rev["RM"]>=6]
X=rev.iloc[:,1:] .drop(columns=["INDUS","AGE"])
print(X)
y=rev["MEDV"]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)
sc = StandardScaler()
sc.fit(X_train)

X_train_std = sc.transform(X_train)
X_test_std = sc.transform(X_test)

linreg = LinearRegression()
linreg.fit(X_train_std, y_train)#the core training alogrithm

y_pred = linreg.predict(X_test_std)

print(X.info)
print(rev.info)

#compute the accuracy of linear regression ,include MSE,EVC
print ("errorvarient:"," ",np.sqrt(metrics.mean_squared_error(y_test, y_pred)))
print('MSE：{}'.format(round(metrics.mean_squared_error(y_pred,y_test),2)))
print('EVC：{}'.format(round(metrics.explained_variance_score(y_pred,y_test),2)))


def plot_learning_curve(estimator, title, X, y, ylim=None, cv=None,n_jobs=None, train_sizes=np.linspace(.1, 1.0, 5)):
    plt.figure()
    plt.title(title)
    if ylim is not None:
        plt.ylim(*ylim)
    plt.xlabel("Training examples")
    plt.ylabel("Score")
    train_sizes, train_scores, test_scores = learning_curve(
        estimator, X, y, cv=cv, n_jobs=n_jobs, train_sizes=train_sizes)
    train_scores_mean = np.mean(train_scores, axis=1)
    train_scores_std = np.std(train_scores, axis=1)
    test_scores_mean = np.mean(test_scores, axis=1)
    #test_scores_min=np.amin(test_scores,axis=1)
    test_scores_std = np.std(test_scores, axis=1)
    plt.grid()

    plt.fill_between(train_sizes, train_scores_mean - train_scores_std,train_scores_mean + train_scores_std, alpha=0.1,color="r")
    plt.fill_between(train_sizes, test_scores_mean - test_scores_std,test_scores_mean + test_scores_std, alpha=0.1, color="g")
    plt.plot(train_sizes, train_scores_mean, 'o-', color="r",label="Training score")
    plt.plot(train_sizes, test_scores_mean, 'o-', color="g",label="test score")

    plt.legend(loc="best")
    return plt

plot_learning_curve(linreg, "Learning curves for Linear regression", X_train_std,y_train, (0.0, 1.01),ShuffleSplit(n_splits=10, test_size=0.2, random_state=0), n_jobs=4)
plt.show()

#show 10 graphs,each graph's x axis represents a feature, y axis represents price
def showdisrt():
    for i in range(0, t.columns.size):
        namelist = t.columns.values.tolist()
        ax = plt.subplot(4, 4, i + 1)
        d1 = pd.Series(t.iloc[:, i])
        min = d1.min()
        max = d1.max()
        step = (max - min) / 5
        x_axis = np.arange(min, max, step)
        plt.xticks()
        plt.title(namelist[i])
        plt.scatter(t.iloc[:, i], y, s=5)
    plt.show()

showdisrt()




